Add nasia-01.jpg and nasia-02.jpg to this folder.
