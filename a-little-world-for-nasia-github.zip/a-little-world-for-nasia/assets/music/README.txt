Optional: add background-music.mp3 to this folder.
