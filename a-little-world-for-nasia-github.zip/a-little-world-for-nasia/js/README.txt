Add the six JavaScript files referenced by index.html to this folder.
