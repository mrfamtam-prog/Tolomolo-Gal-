Add the seven CSS files referenced by index.html to this folder.
